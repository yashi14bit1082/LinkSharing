CREATE TRIGGER SalaryUpdateTrigger
AFTER UPDATE ON employee_info
FOR EACH ROW
  begin
if new.emp_salary<old.emp_salary then
insert into employeeUpdatedSal set emp_name = old.emp_name,
updatedBy = 'yashi',
changedSalary = new.emp_salary, 
updatedDate = now();
end if;
end;
