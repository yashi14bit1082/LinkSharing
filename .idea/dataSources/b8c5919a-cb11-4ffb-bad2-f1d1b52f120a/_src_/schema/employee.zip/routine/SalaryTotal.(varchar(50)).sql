CREATE FUNCTION SalaryTotal(dept_name VARCHAR(50))
  RETURNS INT
  begin
declare SalarySum int;
select sum(emp_salary) into SalarySum
from employee_info
where emp_dept = dept_name;
return SalarySum;
end;
