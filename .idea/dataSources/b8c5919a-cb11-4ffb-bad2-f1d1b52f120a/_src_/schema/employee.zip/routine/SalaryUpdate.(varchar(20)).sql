CREATE PROCEDURE SalaryUpdate(IN dept_name VARCHAR(20))
  begin
update employee_info
set emp_salary = emp_salary + 500
where emp_dept = dept_name;
end;
